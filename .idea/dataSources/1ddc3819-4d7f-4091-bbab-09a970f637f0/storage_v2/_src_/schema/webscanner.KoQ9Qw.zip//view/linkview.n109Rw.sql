create definer = root@localhost view linkview as
select `webscanner`.`t_link_tmp`.`link` AS `link`
from `webscanner`.`t_link_tmp`;

